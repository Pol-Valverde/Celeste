<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="CelesteClassic_Walls" tilewidth="8" tileheight="8" spacing="2" margin="1" tilecount="63" columns="7">
 <image source="CelesteClassic_Walls.png" width="70" height="90"/>
</tileset>
