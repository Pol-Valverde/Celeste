<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="CelesteClassic_Spikes" tilewidth="8" tileheight="8" spacing="2" margin="1" tilecount="1" columns="1">
 <image source="CelesteClassic_Spikes.png" width="10" height="10"/>
</tileset>
