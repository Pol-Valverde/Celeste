<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="CelesteClassic_Everything" tilewidth="8" tileheight="8" spacing="2" margin="1" tilecount="72" columns="8">
 <image source="CelesteClassic_Everything.png" width="80" height="90"/>
</tileset>
