<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="CelesteClassic_Background" tilewidth="8" tileheight="8" spacing="2" margin="1" tilecount="12" columns="3">
 <image source="CelesteClassic_Background.png" width="30" height="40"/>
</tileset>
